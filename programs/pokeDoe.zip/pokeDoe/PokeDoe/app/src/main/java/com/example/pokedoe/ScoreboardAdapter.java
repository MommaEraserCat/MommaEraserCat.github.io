package com.example.pokedoe;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ScoreboardAdapter extends ArrayAdapter<Player> {
    private Context context;
    private List<Player> items;
    // Instance variables

    public ScoreboardAdapter(Context context, List<Player> items) {
        super(context, 0, items);
        this.context = context;
        this.items = items;
    }
    // Constructor

    public View getView(int position, View convertView, ViewGroup parent) {
        Player item = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.player, parent, false);
        }

        TextView name = convertView.findViewById(R.id.nameScoreboard);
        TextView score = convertView.findViewById(R.id.scoreScoreboard);

        name.setText(item.getName());
        score.setText("Score: " + item.getScore());

        return convertView;
    }

}
/* As the name suggests for this class, this is an adapter for the scoreboard. More specifically,
the listView. It syncs the score board and listView. */