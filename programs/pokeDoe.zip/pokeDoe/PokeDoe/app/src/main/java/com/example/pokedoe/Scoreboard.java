package com.example.pokedoe;

import android.content.Intent;
import android.util.Log;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Scoreboard extends AppCompatActivity {

    private List<Player> itemList;
    private ScoreboardAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scoreboard);
        // Sets up the scoreboard via the extended class and the xml.

        TextView scoreboardTitle = findViewById(R.id.scoreboardTitle);
        ListView playerScoreList = findViewById(R.id.playerList);
        Button exitingButton = findViewById(R.id.exitToGameButton);
        // Links xml elements to variables.

        Bundle scoreboardBundle = getIntent().getExtras();
        String userName = "Player";
        // This gets the intent then gets the values out of the intent and appends it to a variable.
        // As well, it creates a userName variable.

        if (scoreboardBundle != null) {
            userName = scoreboardBundle.getString("userNameSend", "Player");
        }
        /* If the scoreboardBundle variable does have values, then it will get values via the key
        value pair. */

        SharedPreferences stats2 = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        // Gets the SharedPreference that is used within this project.

        itemList = new ArrayList<>();
        adapter = new ScoreboardAdapter(this, itemList);
        playerScoreList.setAdapter(adapter);
        // Makes a new ArrayList and Scoreboard adapter. Then it uses the adapter to make the ListView

        Map<String, ?> allEntries = stats2.getAll();
        // Makes a map variable to get all the information from the SharedPreference.

        for (Map.Entry<String, ?> entry : allEntries.entrySet()) {
            String key = entry.getKey();
            if (key.endsWith("_score")) {
                String userNameKey = key.replace("_score", "");

                String value = entry.getValue().toString();
                try {
                    int score = Integer.parseInt(value);
                    Player player = new Player(userNameKey, score);
                    itemList.add(player);
                } catch (NumberFormatException e) {
                    Log.e("Scoreboard", "Failed to parse score for: " + key + " -> " + value);
                }
                Log.d("Scoreboard", "Loaded: " + key + " -> " + entry.getValue());
            }
        }
        /* A for loop is used to gather all values within the SharedPreference. An if statement is
        used to check each value and if the value ends with _score, then it will replace that part
        and get the value. After that, a try catch is used to add the player to the ArrayList which
        is added to the scoreboardAdapter and it continues from there. */

        exitingButton.setOnClickListener(v -> {
            finish();
        });
        // Exit button
    }

}
// Most of this is from the dice game.