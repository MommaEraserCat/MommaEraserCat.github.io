package com.example.pokedoe;

import java.util.*;

public class PokerHands {
    private String pokerHand;
    private int baseChips;
    private int baseMult;
    private List<PlayingCards> contributingCards;

    public PokerHands(String pokerHand, int baseChips, int baseMult, List<PlayingCards> contributingCards) {
        this.pokerHand = pokerHand;
        this.baseChips = baseChips;
        this.baseMult = baseMult;
        this.contributingCards = contributingCards;
    }

    public String getPokerHand() {
        return pokerHand;
    }

    public int getBaseChips() {
        return baseChips;
    }

    public int getBaseMult() {
        return baseMult;
    }

    public void setContributingCards(List<PlayingCards> contributingCards) {
        this.contributingCards = contributingCards;
    }

    public List<PlayingCards> getContributingCards() {
        return contributingCards;
    }


    public static final PokerHands flush_Five = new PokerHands("Flush Five", 160, 16, new ArrayList<>());
    public static final PokerHands flush_House = new PokerHands("Flush House", 140, 14, new ArrayList<>());
    public static final PokerHands five_Of_A_Kind = new PokerHands("Five of A Kind", 120, 12, new ArrayList<>());
    public static final PokerHands royal_Flush = new PokerHands("Royal Flush", 100, 8, new ArrayList<>());
    public static final PokerHands straight_Flush = new PokerHands("Straight Flush", 100, 8, new ArrayList<>());
    public static final PokerHands four_Of_A_Kind = new PokerHands("Four of A Kind", 60, 7, new ArrayList<>());
    public static final PokerHands full_House = new PokerHands("Full House", 40, 4, new ArrayList<>());
    public static final PokerHands flush = new PokerHands("Flush", 35, 4, new ArrayList<>());
    public static final PokerHands straight = new PokerHands("Straight", 30, 4, new ArrayList<>());
    public static final PokerHands three_Of_A_Kind = new PokerHands("Three of A Kind", 30, 3, new ArrayList<>());
    public static final PokerHands two_Pair = new PokerHands("Two Pair", 20, 2, new ArrayList<>());
    public static final PokerHands pair = new PokerHands("Pair", 10, 2, new ArrayList<>());
    public static final PokerHands high_Card = new PokerHands("High Card", 5, 1, new ArrayList<>());
    // Sets the poker hands to be used.

    public static PokerHands evaluate(List<PlayingCards> hand) {
        Map<Integer, Integer> rankCounts = new HashMap<>();
        List<Integer> ranks = new ArrayList<>();
        // Set up

        for (PlayingCards card : hand) {
            ranks.add(card.getCardPosition());
            rankCounts.put(card.getCardPosition(), rankCounts.getOrDefault(card.getCardPosition(), 0) + 1);
        }
        /* Adds the individual cards to ranks and rankCounts by their position. As well, rankCounts
        uses a key value pair. */

        Collections.sort(ranks);
        Set<Integer> uniqueRanksSet = new HashSet<>(ranks);
        List<Integer> uniqueRanks = new ArrayList<>(uniqueRanksSet);
        Collections.sort(uniqueRanks);
        // This block converts ranks into an ArrayList named uniqueRanks.


        boolean isFlush = hand.size() == 5;
        boolean isStraight = uniqueRanks.size() == 5 &&
                uniqueRanks.get(4) - uniqueRanks.get(0) == 4;
        if (uniqueRanks.equals(Arrays.asList(2, 3, 4, 5, 14))) {
            isStraight = true;
        }
        boolean isFiveOfAKind = rankCounts.containsValue(5);
        boolean isFourOfAKind = rankCounts.containsValue(4);
        boolean isThreeOfAKind = rankCounts.containsValue(3);
        boolean isPair = rankCounts.containsValue(2);
        boolean isFullHouse = isThreeOfAKind && isPair;
        List<Integer> royalRanks = Arrays.asList(10, 11, 12, 13, 14);
        /* Sets up boolean variables to be used as poker hands require specific conditions to be
        met. Flush will always occur here as there is only the heart suit. Straights have a unique
        case with the ace as it counts as a 1 or a 11/14 with Balatro. Besides that, straights are
        checked by seeing if subtracting the last value of the highest card by the value of the
        lowest card. If they equal four, it is a straight. There is also the Royal Flush. */

        if (isFlush && rankCounts.size() == 1) return makeResult(PokerHands.flush_Five, hand);
        if (isFlush && rankCounts.size() == 2 && (rankCounts.containsValue(3) && rankCounts.containsValue(2)))
            return makeResult(PokerHands.flush_House, hand);
        if (isFiveOfAKind) return makeResult(PokerHands.five_Of_A_Kind, hand);
        if (isFlush && isStraight && uniqueRanks.containsAll(royalRanks)) return makeResult(PokerHands.royal_Flush, hand);
        if (isFlush && isStraight) return makeResult(PokerHands.straight_Flush, hand);
        if (isFourOfAKind) return makeResult(PokerHands.four_Of_A_Kind, hand);
        if (isFullHouse) return makeResult(PokerHands.full_House, hand);
        if (isFlush) return makeResult(PokerHands.flush, hand);
        if (isStraight) return makeResult(PokerHands.straight, hand);
        if (isThreeOfAKind) return makeResult(PokerHands.three_Of_A_Kind, hand);
        long numPairs = rankCounts.values().stream().filter(count -> count == 2).count();
        if (numPairs == 2) return makeResult(PokerHands.two_Pair, hand);
        if (numPairs == 1) return makeResult(PokerHands.pair, hand);
        return makeResult(PokerHands.high_Card, hand);
        /* This returns the corresponding hand to what is put into the evaluate method by using the
        boolean variables from above. As well, this is done to have a priority order since some
        poker hands are better than others. */
    }

    private static PokerHands makeResult(PokerHands template, List<PlayingCards> hand) {
        PokerHands result = new PokerHands(template.getPokerHand(), template.getBaseChips(), template.getBaseMult(), new ArrayList<>());
        result.setContributingCards(new ArrayList<>(hand));
        return result;
    }
    // Method to help evaluate by making a template of PokerHands for it's values.
}