package com.example.pokedoe;

import android.widget.ImageView;

import java.util.ArrayList;
import java.util.Collections;

public class JokerCards {
    private int addedBaseChips = 0;
    private int addedMult = 0;

    public void banner(int numOfDiscards) {
        if (numOfDiscards == 3) {
            addedBaseChips = 90;
        }
        else if (numOfDiscards == 2) {
            addedBaseChips = 60;
        }
        else if (numOfDiscards == 1) {
            addedBaseChips = 30;
        }
        else {
            addedBaseChips = 0;
        }
        //"Banner is a common Joker which provides +30 Chips for each remaining discard when a hand is played."
    }

    public int fibonacci(ArrayList<ImageView> selectedCards) {
        addedMult = 0;  // reset each time

        for (ImageView cardView : selectedCards) {
            Object tag = cardView.getTag();
            if (tag instanceof PlayingCards) {
                PlayingCards card = (PlayingCards) tag;
                int cardValue = card.getCardPosition();

                if (cardValue == 1 || cardValue == 2 || cardValue == 3 || cardValue == 5 || cardValue == 8) {
                    addedMult += 8;
                }
            }
        }
        return addedMult;
        //"Fibonacci gives a Mult boost to any hand played that contains Aces, 2s, 3s, 5s, or 8s."
    }

    public int abstractJoker() {
        addedMult = 12;
        return addedMult;
        //"The Abstract Joker provides a Mult boost for every Joker card you currently have. It includes itself, so gives a minimum of +3 Mult."
    }

    public int cardSharp(ArrayList<ImageView> currentPokerHand, ArrayList<ArrayList<ImageView>> allPreviousPokerHands, int mult) {
        boolean matchFound = false;

        for (ArrayList<ImageView> previousHand : allPreviousPokerHands) {
            if (handsAreEqual(currentPokerHand, previousHand)) {
                matchFound = true;
                break;
            }
        }

        if (matchFound) {
            return mult * 3;
        } else {
            return mult;
        }
    }
        //"Card Sharp is an uncommon Joker that provides X3 Mult when a hand is played again during the same round."

    private boolean handsAreEqual(ArrayList<ImageView> hand1, ArrayList<ImageView> hand2) {
        if (hand1.size() != hand2.size()) return false;

        ArrayList<Integer> hand1Values = new ArrayList<>();
        ArrayList<Integer> hand2Values = new ArrayList<>();

        for (ImageView cardView : hand1) {
            Object tag = cardView.getTag();
            if (tag instanceof PlayingCards) {
                hand1Values.add(((PlayingCards) tag).getCardPosition());
            }
        }
        for (ImageView cardView : hand2) {
            Object tag = cardView.getTag();
            if (tag instanceof PlayingCards) {
                hand2Values.add(((PlayingCards) tag).getCardPosition());
            }
        }

        Collections.sort(hand1Values);
        Collections.sort(hand2Values);

        return hand1Values.equals(hand2Values);
    }
    /* This method compares the current hand with the previous hand. If they don't equal, then it
    returns false. Otherwise, we use a for loop on both hands to get the value of their cards. If
    they match, it returns the boolean of the comparison. */
}
// Class is not implemented yet.