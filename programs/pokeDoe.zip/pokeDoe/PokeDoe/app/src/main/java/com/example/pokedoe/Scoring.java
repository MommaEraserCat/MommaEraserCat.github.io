package com.example.pokedoe;

import java.util.*;

public class Scoring {
    private int totalChips;
    private String lastHandName;
    private int lastHandBaseScore;
    private int lastHandBonus;
    private int lastHandTotal;
    // Instance variables

    public Scoring() {
        totalChips = 0;
    }

    public int scoreHand(PokerHands hand, List<PlayingCards> handCards) {
        lastHandName = hand.getPokerHand();
        lastHandBaseScore = hand.getBaseChips() * hand.getBaseMult();
        lastHandBonus = calculateBonus(hand, handCards);
        lastHandTotal = lastHandBaseScore + lastHandBonus;
        totalChips += lastHandTotal;

        return lastHandTotal;
    }
    /* This method gets all the information for the poker hand, the base score info of the poker hand,
    the chip amounts of the cards that are played and scored correctly, and totals those in order to
    get a score for the user. */

    private int calculateBonus(PokerHands hand, List<PlayingCards> handCards) {
        String handName = hand.getPokerHand().toLowerCase();

        // Map cards by cardPosition (rank)
        Map<Integer, List<PlayingCards>> rankGroups = new HashMap<>();
        for (PlayingCards card : handCards) {
            int rank = card.getCardPosition();
            rankGroups.computeIfAbsent(rank, k -> new ArrayList<>()).add(card);
        }

        switch (handName) {
            case "high card":
                return getHighestCardChips(handCards);

            case "pair":
                return getGroupChips(rankGroups, 2, 1);

            case "two pair":
                return getGroupChips(rankGroups, 2, 2);

            case "three of a kind":
                return getGroupChips(rankGroups, 3, 1);

            case "straight":
            case "flush":
            case "straight flush":
            case "royal flush":
            case "flush five":
            case "flush house":
                return getAllCardsChips(handCards);

            case "full house":
                int bonus = getGroupChips(rankGroups, 3, 1);
                bonus += getGroupChips(rankGroups, 2, 1);
                return bonus;

            case "four of a kind":
                return getGroupChips(rankGroups, 4, 1);

            case "five of a kind":
                return getGroupChips(rankGroups, 5, 1);

            default:
                return 0;
        }
    }
    /* This method starts by gathering parameters from the PokerHands and PlayingCards class.
    It then gets a hand name to determine values later within the switch case statement. The map is
    made to save the specific cards to the map. The for loop is used to add those cards to the map.
    The computeIfAbsent allows for the add method to work by changing the rank and k to an ArrayList.
    A switch statement is then used to identify all of the poker hands by using the methods below.*/


    private int getHighestCardChips(List<PlayingCards> handCards) {
        int max = 0;
        for (PlayingCards card : handCards) {
            if (card.getCardChips() > max) {
                max = card.getCardChips();
            }
        }
        return max;
    }
    // This method collects the highest chip value by using the handCards parameter.

    private int getAllCardsChips(List<PlayingCards> handCards) {
        int sum = 0;
        for (PlayingCards card : handCards) {
            sum += card.getCardChips();
        }
        return sum;
    }
    // This method collects all of the card chip values by using the handCards parameter.

    private int getGroupChips(Map<Integer, List<PlayingCards>> rankGroups, int groupSize, int maxGroups) {
        int total = 0;
        int groupsFound = 0;

        for (List<PlayingCards> group : rankGroups.values()) {
            if (group.size() == groupSize) {
                for (PlayingCards card : group) {
                    total += card.getCardChips();
                }
                groupsFound++;
                if (groupsFound >= maxGroups) break;
            }
        }
        return total;
    }
    /* This method will acquire multiple groups of values and the size of those groups. Via this, it
    will get the cards' chips depending on if they'd met the conditions. If the maxGroups is lower
    in value than the groupsFound variable, then it will break the loop. At the end, it returns the
    chips from each group. */

    public int getTotalChips() {
        return totalChips;
    }

    public String getLastHandName() {
        return lastHandName;
    }

    public int getLastHandBaseScore() {
        return lastHandBaseScore;
    }

    public int getLastHandBonus() {
        return lastHandBonus;
    }

    public int getLastHandTotal() {
        return lastHandTotal;
    }
    // Getters

    public void resetScore() {
        totalChips = 0;
    }
}