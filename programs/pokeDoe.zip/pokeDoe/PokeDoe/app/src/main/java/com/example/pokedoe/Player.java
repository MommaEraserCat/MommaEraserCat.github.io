package com.example.pokedoe;

public class Player {
    private String name;
    private int totalScore;

    public Player(String name, int totalScore) {
        this.name = name;
        this.totalScore = totalScore;
    }

    public String getName() { return name; }
    public int getScore() { return totalScore; }
}
// Date class for player information.