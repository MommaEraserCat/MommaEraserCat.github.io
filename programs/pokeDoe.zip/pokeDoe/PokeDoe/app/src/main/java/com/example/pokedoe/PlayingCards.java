package com.example.pokedoe;

public class PlayingCards {
    private String cardName;
    private int cardChips;
    private int cardPosition;

    public PlayingCards(String cardName, int cardChips, int cardPosition) {
        this.cardName = cardName;
        this.cardChips = cardChips;
        this.cardPosition = cardPosition;
    }

    public String getCardName() {
        return cardName;
    }

    public int getCardChips() {
        return cardChips;
    }

    public void setCardPosition(int cardPosition) {
        this.cardPosition = cardPosition;
    }

    public int getCardPosition() {
        return cardPosition;
    }

    public static final PlayingCards two_of_hearts = new PlayingCards("Two of Hearts", 2, 2);
    public static final PlayingCards three_of_hearts = new PlayingCards("Three of Hearts", 3, 3);
    public static final PlayingCards four_of_hearts = new PlayingCards("Four of Hearts", 4, 4);
    public static final PlayingCards five_of_hearts = new PlayingCards("Five of Hearts", 5, 5);
    public static final PlayingCards six_of_hearts = new PlayingCards("Six of Hearts", 6, 6);
    public static final PlayingCards seven_of_hearts = new PlayingCards("Seven of Hearts", 7, 7);
    public static final PlayingCards eight_of_hearts = new PlayingCards("Eight of Hearts", 8, 8);
    public static final PlayingCards nine_of_hearts = new PlayingCards("Nine of Hearts", 9, 9);
    public static final PlayingCards ten_of_hearts = new PlayingCards("Ten of Hearts", 10, 10);
    public static final PlayingCards jack_of_hearts = new PlayingCards("Jack of Hearts", 10, 11);
    public static final PlayingCards queen_of_hearts = new PlayingCards("Queen of Hearts", 10, 12);
    public static final PlayingCards king_of_hearts = new PlayingCards("King of Hearts", 10, 13);
    public static final PlayingCards ace_of_hearts = new PlayingCards("Ace of Hearts", 11, 14);
    // Sets the playing cards to be used.
}
