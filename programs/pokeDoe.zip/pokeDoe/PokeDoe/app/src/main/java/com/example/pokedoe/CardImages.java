package com.example.pokedoe;

public class CardImages {

    public static int playingImageLoader(int cardPosition) {
        switch (cardPosition) {
            case 14: return R.drawable.heart_ace;
            case 13: return R.drawable.heart_king;
            case 12: return R.drawable.heart_queen;
            case 11: return R.drawable.heart_jack;
            case 10: return R.drawable.heart_ten;
            case 9: return R.drawable.heart_nine;
            case 8: return R.drawable.heart_eight;
            case 7: return R.drawable.heart_seven;
            case 6: return R.drawable.heart_six;
            case 5: return R.drawable.heart_five;
            case 4: return R.drawable.heart_four;
            case 3: return R.drawable.heart_three;
            case 2: return R.drawable.heart_two;
            default: return R.drawable.joker;
        }
        // Case statement to return the corresponding image for playing cards.
    }
    public static int tarotImageLoader(int tarotNum) {
        if (tarotNum == 1) {
            return R.drawable.tarot_strength;
        }
        else {
            return R.drawable.joker;
        }
        // Case statement to return the corresponding image for tarot cards.
    }
    public static int jokerImageLoader(int jokerNum) {
        switch (jokerNum) {
            case 1: return R.drawable.fibonacci;
            case 2: return R.drawable.card_sharp;
            case 3: return R.drawable.banner;
            case 4: return R.drawable.abstract_joker;
            default: return R.drawable.joker;
        }
        // Case statement to return the corresponding image for joker cards.
    }
}
