package com.example.pokedoe;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private EditText name;
    private TextView userNameText;
    private TextView pokerHand;
    private TextView chips;
    private TextView timesSign;
    private TextView mult;
    private TextView scoreTotal;
    private TextView handsAmount;
    private TextView discardsAmount;
    private Button playHands;
    private Button discardHands;
    private Button scoreboard;
    private ImageView jokerFibo;
    private ImageView jokerCardSharp;
    private ImageView jokerBanner;
    private ImageView jokerAbstract;
    private ImageView tarotStrength1;
    private ImageView tarotStrength2;
    private TextView cardChipSummary;
    private TextView totalScoreForUser;
    private int userOverallScore;
    private boolean strengthModeActive = false;
    private int strengthCardsLeft = 2;
    private int strengthSelectionsMade = 0;
    private List<PlayingCards> strengthSelectedCards = new ArrayList<>();
    private int discardTracker = 0;
    private static final int max_Discards = 3;
    private int playTracker = 0;
    private static final int max_Plays = 3;
    private ImageView[] cardImageViews = new ImageView[7];
    private ArrayList<ImageView> selectedCards = new ArrayList<>();
    private List<Integer> deck = new ArrayList<>();
    private List<Integer> hand = new ArrayList<>();
    // Instance variables.


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.userNameInput);
        userNameText = findViewById(R.id.name);
        pokerHand = findViewById(R.id.pokerHands);
        chips = findViewById(R.id.chipsText);
        timesSign = findViewById(R.id.timesSign);
        mult = findViewById(R.id.multText);
        scoreTotal = findViewById(R.id.scoreText);
        handsAmount = findViewById(R.id.numberOfPlays);
        discardsAmount = findViewById(R.id.numberOfDiscards);
        playHands = findViewById(R.id.playHandButton);
        discardHands = findViewById(R.id.discardHandButton);
        scoreboard = findViewById(R.id.scoreboardButton);
        jokerFibo = findViewById(R.id.jokerFibo);
        jokerCardSharp = findViewById(R.id.jokerCardSharp);
        jokerBanner = findViewById(R.id.jokerBanner);
        jokerAbstract = findViewById(R.id.jokerAbstract);
        tarotStrength1 = findViewById(R.id.tarotStrength1);
        tarotStrength2 = findViewById(R.id.tarotStrength2);
        cardImageViews[0] = findViewById(R.id.cardSlot1);
        cardImageViews[1] = findViewById(R.id.cardSlot2);
        cardImageViews[2] = findViewById(R.id.cardSlot3);
        cardImageViews[3] = findViewById(R.id.cardSlot4);
        cardImageViews[4] = findViewById(R.id.cardSlot5);
        cardImageViews[5] = findViewById(R.id.cardSlot6);
        cardImageViews[6] = findViewById(R.id.cardSlot7);
        cardChipSummary = findViewById(R.id.cardChipSummary);
        totalScoreForUser = findViewById(R.id.totalScoreForUser);
        // Finding the ui elements and setting them to variables for the main class.

        deckModel();
        imageSetter();
        sortHandByCardPosition();
        for (ImageView cardView : cardImageViews) {
            cardView.setOnClickListener(v -> toggleCardSelection((ImageView) v));
        }
        /* Method callers to set the deck, images, and images position. As well, a for loop to set
        OnClickListeners for the cards*/

        tarotStrength1.setOnClickListener(v -> {
            if (strengthCardsLeft <= 0 || tarotStrength1.getAlpha() < 1f) {
                Toast.makeText(this, "This Strength card has already been used.", Toast.LENGTH_SHORT).show();
                return;
            }
            strengthModeActive = true;
            Toast.makeText(this, "Strength activated! Select up to 2 cards to boost.", Toast.LENGTH_SHORT).show();
        });
        tarotStrength2.setOnClickListener(v -> {
            if (strengthCardsLeft <= 0 || tarotStrength2.getAlpha() < 1f) {
                Toast.makeText(this, "This Strength card has already been used.", Toast.LENGTH_SHORT).show();
                return;
            }
            strengthModeActive = true;
            Toast.makeText(this, "Strength activated! Select up to 2 cards to boost.", Toast.LENGTH_SHORT).show();
        });
        /* The onClickListeners for the tarot cards. What's going on inside is that it checks if
        there are tarot cards to use or if the image is greyed out. If so, a toast is made then a
        return is used. It sets the game into a mode to use the strength properly. After, it gives a
        toast for the user to be aware of what has happened. */

        playHands.setOnClickListener(v -> {
            if (playTracker >= max_Plays) {
                Toast.makeText(this, "No plays left!", Toast.LENGTH_SHORT).show();
                return;
            }
            if (selectedCards.isEmpty()) {
                Toast.makeText(this, "Select at least one card to play.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (selectedCards.size() > 5) {
                Toast.makeText(this, "You can only play up to 5 cards at a time.", Toast.LENGTH_SHORT).show();
                return;
            }
            /* Checks to see if the user has plays left, if they selected a card, and if they try to
            select more than one card. */

            List<PlayingCards> playedCards = new ArrayList<>();
            for (ImageView card : selectedCards) {
                int index = getCardIndex(card);
                if (index != -1) {
                    int cardId = hand.get(index);
                    PlayingCards playingCard = getPlayingCardById(cardId);
                    if (playingCard != null) {
                        playedCards.add(playingCard);
                    }
                }
            }
            /* This block check each card from the user's selection and adds it to the ArrayList of
            playedCards. */

            PokerHands resultHand = PokerHands.evaluate(playedCards);
            // A method call from PokerHands class.

            List<PlayingCards> contributing = resultHand.getContributingCards();
            for (ImageView cardView : selectedCards) {
                int index = getCardIndex(cardView);
                if (index != -1) {
                    int cardId = hand.get(index);
                    PlayingCards playingCard = getPlayingCardById(cardId);
                    boolean isContributing = false;
                    for (PlayingCards c : contributing) {
                        if (c.getCardName().equals(playingCard.getCardName())) {
                            isContributing = true;
                            break;
                        }
                    }
                }
            }
            // TODO

            pokerHand.setText(resultHand.getPokerHand());
            chips.setText(String.valueOf(resultHand.getBaseChips()));
            mult.setText(String.valueOf(resultHand.getBaseMult()));
            int score = resultHand.getBaseChips() * resultHand.getBaseMult();
            scoreTotal.setText(String.valueOf(score));
            // Sets values to the TextViews.

            Collections.sort(playedCards, Comparator.comparingInt(PlayingCards::getCardPosition).reversed());
            // Sorts the playedCards.

            if (!playedCards.isEmpty()) {
                int chipTotal = 0;
                List<String> cardDetailsUsed = new ArrayList<>();

                String pokerHandResult = resultHand.getPokerHand().toLowerCase();

                if (pokerHandResult.contains("flush") || pokerHandResult.contains("straight")) {
                    for (PlayingCards card : playedCards) {
                        chipTotal += card.getCardChips();
                        cardDetailsUsed.add(card.getCardName() + " (" + card.getCardChips() + ")");
                    }
                }
                else if (pokerHandResult.contains("pair")) {
                    Map<Integer, Integer> rankCount = new HashMap<>();
                    for (PlayingCards card : playedCards) {
                        int rank = card.getCardPosition() % 13;
                        rankCount.put(rank, rankCount.getOrDefault(rank, 0) + 1);
                    }
                    for (PlayingCards card : playedCards) {
                        int rank = card.getCardPosition() % 13;
                        if (rankCount.get(rank) >= 2) {
                            chipTotal += card.getCardChips();
                            cardDetailsUsed.add(card.getCardName() + " (" + card.getCardChips() + ")");
                        }
                    }
                }
                else {
                    int highestPosition = playedCards.get(0).getCardPosition();
                    for (PlayingCards card : playedCards) {
                        if (card.getCardPosition() == highestPosition) {
                            chipTotal += card.getCardChips();
                            cardDetailsUsed.add(card.getCardName() + " (" + card.getCardChips() + ")");
                        }
                    }
                }
                // All of these blocks of code gives the chips from cards to be added together later.

                String chipDetails = "Chips from Cards: " + String.join(", ", cardDetailsUsed);
                int totalScoringWithCards = score + chipTotal;
                userOverallScore += totalScoringWithCards;
                cardChipSummary.setAlpha(0f);
                cardChipSummary.setText(chipDetails + "\nTotal Chips: " + chipTotal);
                totalScoreForUser.setText("Total Score: " + userOverallScore);
                cardChipSummary.animate().alpha(1f).setDuration(500);
                // Changes TextViews and creates variables for the score.
            }

            for (ImageView card : selectedCards) {
                int index = getCardIndex(card);
                if (index != -1) {
                    int newCard = drawUniqueCard();
                    hand.set(index, newCard);
                    cardImageViews[index].setImageResource(CardImages.playingImageLoader(newCard));
                }
            }
            /* Afterwards, a for loop is used to go through each card. From there, it will set the
            index of card to a variable. After, it sets the hand's index to the new card while
            changing the card afterwards. */


            SharedPreferences stats = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            SharedPreferences.Editor statsEditor = stats.edit();
            String userNameStr = name.getText().toString().trim();
            String lastUser = stats.getString("last_user", "");
            if (!userNameStr.equals(lastUser)) {
                stats.edit().putString("last_user", userNameStr).apply();
            }
            String fullText = totalScoreForUser.getText().toString();
            String scoreNumber = fullText.replaceAll("\\D+", "");
            statsEditor.putString(userNameStr + "_score", scoreNumber);
            statsEditor.apply();
            /* Some of this is from the dice game program. And the other stuff is just values for
            this specific program. */

            playTracker++;
            String playAmountString = String.valueOf(max_Plays - playTracker);
            handsAmount.setText("Plays: " + playAmountString);
            sortHandByCardPosition();
            /* As the last thing, it will increment the playTracker, sets a string to a
            String.valueOf, sets the TextView and then calls the sort method. */
        });


        discardHands.setOnClickListener(v -> {
            if (discardTracker >= max_Discards) {
                Toast.makeText(this, "No discards left!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (selectedCards.isEmpty()) {
                Toast.makeText(this, "Select at least one card to discard.", Toast.LENGTH_SHORT).show();
                return;
            }

            if (selectedCards.size() > 5) {
                Toast.makeText(this, "You can only discard up to 5 cards at a time.", Toast.LENGTH_SHORT).show();
                return;
            }

            for (ImageView card : selectedCards) {
                int index = getCardIndex(card);
                if (index != -1) {
                    int newCard = drawUniqueCard();
                    hand.set(index, newCard);
                    cardImageViews[index].setImageResource(CardImages.playingImageLoader(newCard));
                }
            }

            discardTracker++;
            String discardAmountString = String.valueOf(max_Discards - discardTracker);
            discardsAmount.setText("Discards: " + discardAmountString);
            sortHandByCardPosition();
        });
        /* The setOnClickListener starts by checking if there are any discards left. After, it makes
        an if statement that checks if cards are selected. Then, it makes an if statement that checks
        if more than 5 cards are selected. All of these will use a toast then use the return
        keyword. Afterwards, a for loop is used to go through each card. From there, it will
        set the index of card to a variable. After, it sets the hand's index to the new card while
        changing the card afterwards. As the last thing, it will increment the discardTracker, sets
        a string to a String.valueOf, sets the TextView and then calls the sort method. */

        scoreboard.setOnClickListener(v -> {
            Intent scoreboardIntent = new Intent(getBaseContext(), Scoreboard.class);
            String userNameStr = name.getText().toString().trim();
            scoreboardIntent.putExtra("userNameSend", userNameStr);
            startActivity(scoreboardIntent);
        });
        /* Uses the scoreboard as made in the dice game projects. */
    }

    private int drawUniqueCard() {
        Random rand = new Random();
        int newCard;
        do {
            newCard = rand.nextInt(14 - 2 + 1) + 2;  // Cards from 2 to 14
        } while (hand.contains(newCard));
        return newCard;
    }
    /* This method creates a random object while also making a new variable. Then a do while is used
    to set the newCard variable as a random card by using random's method nextInt with a formula I
    got from the internet. And while the hand contains this newCard, it returns the newCard. */

    private int getCardIndex(ImageView cardView) {
        for (int i = 0; i < cardImageViews.length; i++) {
            if (cardImageViews[i] == cardView) {
                return i;
            }
        }
        return -1;
    }
    /* In this method, it uses a for loop to read through the cardImageViews array. And if the index
    of the array matches the ImageView then it will return the variable from the for loop.
    Otherwise, it will return -1 which means that the index isn't found. */

    private void deckModel() {
        for (int card = 2; card < 15; card++) {
            deck.add(card);
        }
        Collections.shuffle(deck);
        for (int card = 0; card < 7; card++) {
            hand.add(deck.remove(0));
        }
    }
    // This method creates the deck and the hand. As well, it shuffles the deck.


    private void sortHandByCardPosition() {
        List<Integer> currentHand = new ArrayList<>(hand);

        Collections.sort(currentHand, (card1, card2) -> {
            PlayingCards pc1 = getPlayingCardById(card1);
            PlayingCards pc2 = getPlayingCardById(card2);
            if (pc1 == null || pc2 == null) return 0;
            return Integer.compare(pc2.getCardPosition(), pc1.getCardPosition());
        });

        for (int i = 0; i < currentHand.size(); i++) {
            int cardId = currentHand.get(i);
            cardImageViews[i].setImageResource(CardImages.playingImageLoader(cardId));
        }

        hand.clear();
        hand.addAll(currentHand);
    }
    /* This method will sort the cards by sorting the ArrayList of currentHand in descending order.
    Afterwards, it will then set the ImageViews to their correct ImageViews. Then it will clear the
    hand list and add to currentHand to loop again when needed. */

    private void imageSetter() {
        for (int i = 0; i < hand.size(); i++) {
            int card = hand.get(i);
            cardImageViews[i].setImageResource(CardImages.playingImageLoader(card));
        }
        /* This method uses a for loop that gets each card from the hand and displays the
        corresponding image. */
    }

    private void toggleCardSelection(ImageView cardView) {
        int index = getCardIndex(cardView);
        if (index == -1) return;

        if (strengthModeActive) {
            if (strengthSelectedCards.size() >= 2) {
                Toast.makeText(this, "You can only select up to 2 cards for Strength.", Toast.LENGTH_SHORT).show();
                return;
            }
            cardView.setAlpha(0.5f);
            int cardId = hand.get(index);
            PlayingCards card = getPlayingCardById(cardId);
            if (card != null) {
                strengthSelectedCards.add(card);
                if (strengthSelectedCards.size() == 2) {
                    applyStrength();
                }
            }
        }

        else {
            if (selectedCards.contains(cardView)) {
                cardView.setAlpha(1f);
                selectedCards.remove(cardView);
            } else {
                cardView.setAlpha(0.5f);
                selectedCards.add(cardView);
            }
        }
    }
    /* This method gives a way for the program to see if we are in the tarot state and if we aren't,
    then it will just give a visual indicator for the user on which cards they have or haven't
    selected. */

    private void applyStrength() {
        for (PlayingCards card : strengthSelectedCards) {
            int currentId = card.getCardPosition();

            int index = hand.indexOf(currentId);
            if (index != -1) {
                int newCardId = increaseCardRank(hand.get(index));
                hand.set(index, newCardId);
                cardImageViews[index].setImageResource(CardImages.playingImageLoader(newCardId));
            }
        }
        Toast.makeText(this, "Strength applied! Selected cards' rank increased.", Toast.LENGTH_SHORT).show();

        strengthSelectedCards.clear();
        strengthModeActive = false;
        // Clears selection

        if (strengthCardsLeft == 2) {
            tarotStrength1.setAlpha(0.5f);
            tarotStrength1.setEnabled(false);
        } else if (strengthCardsLeft == 1) {
            tarotStrength2.setAlpha(0.5f);
            tarotStrength2.setEnabled(false);
        }
        // Greys out the used tarot cards.

        strengthCardsLeft--;
        if (strengthCardsLeft == 0) {
            Toast.makeText(this, "No Strength cards left!", Toast.LENGTH_SHORT).show();
        }
        for (ImageView cardView : cardImageViews) {
            cardView.setAlpha(1f);
        }
    }
    /* This method is the way to use the tarot cards. It uses the increaseCardRank to increase cards'
    values based on their index. */

    private int increaseCardRank(int cardId) {
        int suit = (cardId - 1) / 14;
        int rank = (cardId - 1) % 14 + 1;

        if (rank == 14) {
            rank = 2;
        } else {
            rank++;
        }

        return (suit * 14) + rank;
    }
    // This method will increase the card ranks for the tarot usage.

    private PlayingCards getPlayingCardById(int id) {
        switch (id) {
            case 2: return PlayingCards.two_of_hearts;
            case 3: return PlayingCards.three_of_hearts;
            case 4: return PlayingCards.four_of_hearts;
            case 5: return PlayingCards.five_of_hearts;
            case 6: return PlayingCards.six_of_hearts;
            case 7: return PlayingCards.seven_of_hearts;
            case 8: return PlayingCards.eight_of_hearts;
            case 9: return PlayingCards.nine_of_hearts;
            case 10: return PlayingCards.ten_of_hearts;
            case 11: return PlayingCards.jack_of_hearts;
            case 12: return PlayingCards.queen_of_hearts;
            case 13: return PlayingCards.king_of_hearts;
            case 14: return PlayingCards.ace_of_hearts;
            default: return null;
        }
    }
    // As the method says, it returns cards based on their id/position.

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("playTracker", playTracker);
        outState.putInt("discardTracker", discardTracker);

        int[] handArray = new int[hand.size()];
        for (int i = 0; i < hand.size(); i++) {
            handArray[i] = hand.get(i);
        }
        outState.putIntArray("hand", handArray);
        outState.putString("pokerHand", pokerHand.getText().toString());
        outState.putString("chips", chips.getText().toString());
        outState.putString("mult", mult.getText().toString());
        outState.putString("scoreTotal", scoreTotal.getText().toString());
        outState.putString("totalScoreForUser", totalScoreForUser.getText().toString());
        outState.putBoolean("strengthModeActive", strengthModeActive);
        outState.putInt("strengthCardsLeft", strengthCardsLeft);
    }
    // This method saves the values.

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        playTracker = savedInstanceState.getInt("playTracker", 0);
        discardTracker = savedInstanceState.getInt("discardTracker", 0);

        String playAmountString = String.valueOf(max_Plays - playTracker);
        handsAmount.setText("Plays: " + playAmountString);

        String discardAmountString = String.valueOf(max_Discards - discardTracker);
        discardsAmount.setText("Discards: " + discardAmountString);

        int[] restoredHand = savedInstanceState.getIntArray("hand");
        if (restoredHand != null) {
            hand.clear();
            for (int i = 0; i < restoredHand.length; i++) {
                hand.add(restoredHand[i]);
                cardImageViews[i].setImageResource(CardImages.playingImageLoader(restoredHand[i]));
            }
        }

        String pokerHandStr = savedInstanceState.getString("pokerHand", "");
        String chipsStr = savedInstanceState.getString("chips", "");
        String multStr = savedInstanceState.getString("mult", "");
        String scoreTotalStr = savedInstanceState.getString("scoreTotal", "");
        String totalScoreForUserStr = savedInstanceState.getString("totalScoreForUser", "");

        pokerHand.setText(pokerHandStr);
        chips.setText(chipsStr);
        mult.setText(multStr);
        scoreTotal.setText(scoreTotalStr);
        totalScoreForUser.setText(totalScoreForUserStr);

        strengthModeActive = savedInstanceState.getBoolean("strengthModeActive", false);
        strengthCardsLeft = savedInstanceState.getInt("strengthCardsLeft", 2);
    }
    // For landscape mode. Updates ui by using savedInstanceState values.

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
        // This method will inflate the menu with the xmlns layout, menu_main.
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_gameInfo) {
            GameInfoMenu gameInfo = new GameInfoMenu();
            gameInfo.show(getSupportFragmentManager(), "123");
            return true;
        }
        else if (id == R.id.action_pokerHands) {
            PokerHandInfoMenu handInfo = new PokerHandInfoMenu();
            handInfo.show(getSupportFragmentManager(), "123");
            return true;
        }
        else if (id == R.id.action_about) {
            AboutInfoMenu aboutInfo = new AboutInfoMenu();
            aboutInfo.show(getSupportFragmentManager(), "123");
            return true;
        }
        return super.onOptionsItemSelected(item);
        // This method gets the item id then creates the option menus via the item id.
    }
}